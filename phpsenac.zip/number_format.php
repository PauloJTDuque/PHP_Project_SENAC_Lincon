<?php
$number = 1234.5600;
$number = number_format($number, 2, '.', '');

echo $number;
